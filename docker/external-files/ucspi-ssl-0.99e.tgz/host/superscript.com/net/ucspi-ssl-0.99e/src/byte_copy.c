/* Public domain. */

#include "byte.h"

void byte_copy(register void *to,register unsigned int n,register const void *from)
{
  register char *t = to;
  register const char *f = from;

  for (;;) {
    if (!n) return; *t++ = *f++; --n;
    if (!n) return; *t++ = *f++; --n;
    if (!n) return; *t++ = *f++; --n;
    if (!n) return; *t++ = *f++; --n;
  }
}

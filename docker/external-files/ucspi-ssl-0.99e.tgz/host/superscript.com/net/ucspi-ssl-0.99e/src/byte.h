/* Public domain. */

#ifndef BYTE_H
#define BYTE_H


extern unsigned int byte_chr(const char *, unsigned int n, int);
extern void byte_copy(void *, unsigned int, const void *);
extern void byte_copyr(char *, unsigned int, const char *);
extern int byte_diff(const void *, unsigned int n, const void *);
extern void byte_zero(void *, unsigned int);

#define byte_equal(s,n,t) (!byte_diff((s),(n),(t)))

#endif

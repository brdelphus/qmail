#ifndef BYTE_H
#define BYTE_H

/**
  * @file byte.h	
  * @authors djb, feh, jmh
  * @ref s/qmail
  */

extern unsigned int byte_chr(char *, unsigned int, int);
extern unsigned int byte_rchr(char *, unsigned int, int);
extern void byte_copy(char *, unsigned int, const char *);
extern void byte_copyr(char *, unsigned int, const char *);
extern int byte_diff(const char *, unsigned int, const char *);
extern void byte_zero(char *, unsigned int);
extern void byte_fill(char *, unsigned int, int);

#define byte_equal(s,n,t) (!byte_diff((s),(n),(t)))

#endif

#ifndef NDELAY_H
#define NDELAY_H

/**
  * @file ndelay.h
  * @author djb
  * @ref s/qmail
  */

int ndelay_on(int);
int ndelay_off(int);

#endif

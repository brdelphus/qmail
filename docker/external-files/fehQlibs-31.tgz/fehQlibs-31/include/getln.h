#ifndef GETLN_H
#define GETLN_H

#include "buffer.h"
#include "stralloc.h"

/*
 *  Revision 20240929, Erwin Hoffmann
 *  - renamed sgetln to getln2
*/

extern int getln(buffer *,stralloc *,int *,int);
extern int getln2(buffer *,stralloc *,char **,unsigned int *,int);

#endif

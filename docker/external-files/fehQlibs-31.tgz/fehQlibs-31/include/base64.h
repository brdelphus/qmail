#ifndef BASE64_H
#define BASE64_H

#include "stralloc.h"

extern int b64decode(const unsigned char *in, int l, stralloc *out);
extern int b64encode(stralloc *in, stralloc *out);

#endif

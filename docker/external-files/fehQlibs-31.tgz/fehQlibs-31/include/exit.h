#ifndef EXIT_H
#define EXIT_H

/**
  * @file exit.h
  * @author djb
  * @ref qmail
  * @brief convenience header 
*/

extern void _exit(int);

#endif

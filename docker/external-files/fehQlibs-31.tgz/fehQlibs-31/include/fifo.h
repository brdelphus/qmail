#ifndef FIFO_H
#define FIFO_H

/**
  * @file fifo.h
  * @author djb
  * @ref s/qmail
  */

int fifo_make(char *,int);

#endif

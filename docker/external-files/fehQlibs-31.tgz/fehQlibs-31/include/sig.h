#ifndef SIG_H
#define SIG_H

/*
 *  Revision 20240720, Erwin Hoffmann, jmh
 *  Revision 20160714, Kai Peter
 *  - updated some declarations no new(er) one's from ucspi-tcp-0.88
*/

/* new(er) declarations from ucspi-tcp-0.88: */
extern int sig_alarm;
extern int sig_child;
extern int sig_cont;
extern int sig_hangup;
extern int sig_pipe;
extern int sig_term;

extern void (*sig_defaulthandler)(int);
extern void (*sig_ignorehandler)(int);

extern void sig_catch(int,void (*)(int));
#define sig_ignore(s) (sig_catch((s),sig_ignorehandler))
#define sig_uncatch(s) (sig_catch((s),sig_defaulthandler))

extern void sig_block(int);
extern void sig_unblock(int);
extern void sig_blocknone(void);
extern void sig_pause(void);

extern void sig_dfl(int);

/* declaration of (net)qmail package (untouched) */
extern void sig_miscignore(void);
extern void sig_bugcatch(void (*)(int));

extern void sig_pipeignore(void);
extern void sig_pipedefault(void);

extern void sig_contblock(void);
extern void sig_contunblock(void);
extern void sig_contcatch(void (*)(int));
extern void sig_contdefault(void);

extern void sig_termblock(void);
extern void sig_termunblock(void);
extern void sig_termcatch(void (*)(int));
extern void sig_termdefault(void);

extern void sig_alarmblock(void);
extern void sig_alarmunblock(void);
extern void sig_alarmcatch(void (*)(int));
extern void sig_alarmdefault(void);

extern void sig_childblock(void);
extern void sig_childunblock(void);
extern void sig_childcatch(void (*)(int));
extern void sig_childdefault(void);

extern void sig_hangupblock(void);
extern void sig_hangupunblock(void);
extern void sig_hangupcatch(void (*)(int));
extern void sig_hangupdefault(void);

#endif

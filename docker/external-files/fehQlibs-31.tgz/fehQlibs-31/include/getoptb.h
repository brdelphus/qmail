#ifndef BGETOPT_H
#define BGETOPT_H

/*
 *  Revision 20240731, Erwin Hoffmann
 *  - added getoptb() prototype
 *  Revision 20160714, Kai Peter
 *  - consolidated 'sgetopt.h' and 'subgetopt.h' into '(b)getopt.h'
*/

#define optarg subgetoptarg
#define optind subgetoptind
#define optpos subgetoptpos
#define optproblem subgetoptproblem
#define optprogname subgetoptprogname
#define opteof subgetoptdone

#define SUBGETOPTDONE -1

extern int getoptb(int,char **,char *);

extern int subgetopt(int,char **,char *);
extern char *subgetoptarg;
extern int subgetoptind;
extern int subgetoptpos;
extern int subgetoptproblem;
extern char *subgetoptprogname;
extern int subgetoptdone;

extern int opterr;

#endif

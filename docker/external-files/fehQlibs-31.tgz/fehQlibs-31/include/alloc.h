#ifndef ALLOC_H
#define ALLOC_H

extern void *alloc(unsigned int);
extern void alloc_free(void *);
extern int alloc_re(void **, unsigned int, unsigned int);

/* use these names in the future */
#define qfree alloc_free
#define qrealloc alloc_re

#endif

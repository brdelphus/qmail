#ifndef CONSTMAP_H
#define CONSTMAP_H

typedef unsigned long constmap_hash;

struct constmap {
  int num;
  constmap_hash mask;
  constmap_hash *hash;
  int *first;
  int *next;
  char **input;
  int *inputlen;
};

extern int constmap_init(struct constmap *,const char *,int,int);
extern int constmap_init_char(struct constmap *,const char *,int,int,char);
extern void constmap_free(struct constmap *);
extern char *constmap(struct constmap *,const char *,int);
extern char *constmap_get(struct constmap *, int);
extern int constmap_index(struct constmap *,const char *,int);

#endif

#ifndef REMOTEINFO_H
#define REMOTEINFO_H

#include "stralloc.h"
#include "uint_t.h"

extern int remoteinfo(stralloc *,char [16],uint16,char [16],uint16,unsigned int,uint32);

#endif

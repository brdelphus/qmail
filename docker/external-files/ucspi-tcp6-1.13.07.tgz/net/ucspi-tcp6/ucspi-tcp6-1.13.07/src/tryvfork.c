int main()
{
  vfork();
}

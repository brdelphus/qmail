Installation supplements
========================

Use the conf-* files in the main directory for your adjustments:

1. Plattform dependent customization
------------------------------------

- conf-cc (don't need to be touched -- except if clang support is needed).
- conf-ld (remove option '-m64' and/or replace it with your architecure; 
           ie. installing on x86-32 needs removing this flag)

- conf-man (target for man-pages => /usr/share/man)

Note: This version will compile and work on a RasPi 3!

2. Installation procedure
-------------------------

Usually, you just install the package with

- package/install

3. Individual treatment
-----------------------

- package/compile -- just compile
- package/man -- install man-pages
- package/upgrade -- for new versions
- package/report -- report success+sysdeps to feh@fehcom.de

4. Testing
----------

- package/rts -- after compilation!

For more details see README.rts.

The rts tests can also be executed manually:

- cd ./compile
- sh ./rts.it

The displayed results show the behavior of the executables.
The tests include 'positive' and 'negative' ramifications. 


Erwin Hoffmann, July 2019.
